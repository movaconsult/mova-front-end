document.addEventListener('DOMContentLoaded', () => {
    const voucherName = sessionStorage.getItem('selectedVoucher');
    if (voucherName) {
        document.getElementById('voucher-name').innerText = voucherName;
    }
});

function processPayment() {
    // Simulate payment success
    alert('Payment Successful!');

    // After payment, call API to generate voucher (placeholder)
    const voucherCode = 'BOVA-' + Math.floor(Math.random() * 9000 + 1000);
    sessionStorage.setItem('voucherCode', voucherCode);

    window.location.href = 'success.html';
}
