function selectVoucher(voucherName) {
    sessionStorage.setItem('selectedVoucher', voucherName);
    window.location.href = 'checkout.html';
}
